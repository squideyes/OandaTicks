The 'CLICK HERE to Deploy' script will convert all the pngs in 'thepngs' to icons. It takes a few moments (maybe 5 minutes) to finish, be patient. If you want to keep the pngs, make a copy of 'thepngs'. Or just don't run the script.

If you can, use Axialis Iconworkshop or some other program to convert the icons, png2ico can produce alpha issues for some icons. Peep the 'Weda' folder in 'Things'.

If you're on a mac, you'll have to find a utility to convert the pngs to icns.
One such utility is called iConverter. I'm not really fond of it but it works...kinda. Chances are, someone will make a proper port and release it...eventually.

Same thing goes for Linux users, you'll have to rename the pngs yourself or wait for someone to release a proper port.



This is all due to size constraints.